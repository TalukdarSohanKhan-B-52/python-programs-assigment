# Python Assignment Documentation

## Student Details

- **Name:** Sohan
- **Enrollment Number:** 25004500210082
- **Semester:** 3
- **Division:** B

---

# Project Title

**Python Programming Assignment**

---

# Objective

The objective of this project is to demonstrate the implementation of Python programming concepts such as functions, loops, conditional statements, file handling, exception handling, and object-oriented programming (OOP).

---

# Project Description

This Python project consists of several functions and classes that perform different operations related to a banking system.

The program includes:

- Compound Interest Calculation
- Penalty Fee Calculation
- Transaction Processing
- Interactive Command Loop
- Log File Parsing
- Audit Filter
- Data Cleaning
- File Handling
- Custom Exception Handling
- Account Management System
- Savings Account
- Current Account
- Credit Account
- Batch Settlement

---

# Python Concepts Used

- Variables and Data Types
- Operators
- Conditional Statements (if-else)
- While Loop
- For Loop
- Functions
- Lists
- Tuples
- Sets
- Dictionaries
- Lambda Functions
- Closures
- File Handling
- Exception Handling
- Classes and Objects
- Constructors
- Encapsulation
- Inheritance
- Polymorphism

---

# Files Included

1. main.py
2. documentation.md

---

# How to Run the Program

1. Open the project folder.
2. Open Terminal or Command Prompt.
3. Run the following command:

```bash
python main.py
```

---

# Expected Output

The program demonstrates different Python concepts by performing banking operations such as account creation, settlement processing, file handling, and exception handling. It executes successfully and displays the required output on the console.

---

# Conclusion

This project helped in understanding the practical implementation of Python programming concepts including functions, loops, file handling, exception handling, and object-oriented programming. It also improved problem-solving and coding skills.

---

# Submitted By

**Name:** Sohan

**Enrollment Number:** 25004500210082

**Semester:** 3

**Division:** B