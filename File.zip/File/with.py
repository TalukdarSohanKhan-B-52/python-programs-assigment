
with open("employee.txt", "w") as f:
    f.write("Employee Salary Management\n")
    f.write("Employee ID: " + input("Enter Employee ID: ") + "\n")
    f.write("Name: " + input("Enter Employee Name: ") + "\n")
    f.write("Basic Salary: " + input("Enter Basic Salary: ") + "\n")

print("File written successfully!\n")

with open("employee.txt", "r") as f:
    data = f.read()

print("File Contents:")
print(data)
