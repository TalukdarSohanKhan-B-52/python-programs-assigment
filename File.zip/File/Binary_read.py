
f = open("employee.txt", "rb")

data = f.read()

print(data)

f.close()